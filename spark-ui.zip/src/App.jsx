import { useEffect, useMemo, useState } from 'react'
import visteonLogo from './assets/visteon-logo.jpg'
import './spark.css'

const jobs = [
  { id: 1, company: 'Linear', role: 'Product Design Intern', type: 'Internship', location: 'Remote · India', salary: '₹35k / month', category: 'Design', initials: 'L', color: 'lavender', posted: '2 days ago', featured: true },
  { id: 2, company: 'Razorpay', role: 'Associate Software Engineer', type: 'Full-time', location: 'Bengaluru · Hybrid', salary: '₹8–12 LPA', category: 'Engineering', initials: 'R', color: 'blue', posted: '1 day ago' },
  { id: 3, company: 'Groww', role: 'Junior Product Analyst', type: 'Full-time', location: 'Bengaluru · On-site', salary: '₹7–10 LPA', category: 'Product', initials: 'G', color: 'green', posted: '3 days ago' },
  { id: 4, company: 'Notion', role: 'Content & Community Intern', type: 'Internship', location: 'Remote · India', salary: '₹25k / month', category: 'Marketing', initials: 'N', color: 'cream', posted: '4 days ago' },
  { id: 5, company: 'Zerodha', role: 'Customer Experience Associate', type: 'Full-time', location: 'Pune · Hybrid', salary: '₹6–8 LPA', category: 'Operations', initials: 'Z', color: 'peach', posted: '5 days ago' },
  { id: 6, company: 'CRED', role: 'Visual Design Intern', type: 'Internship', location: 'Mumbai · Hybrid', salary: '₹30k / month', category: 'Design', initials: 'C', color: 'dark', posted: '1 week ago' },
]

const testimonials = [
  { quote: 'I landed my first product design role just three weeks after graduating. Spark made the whole process feel less overwhelming.', name: 'Aisha Nair', role: 'Product Designer at Linear', initials: 'AN', color: 'avatar-peach' },
  { quote: 'The roles here are actually made for people starting out. I found a team that cared more about how I think than my years of experience.', name: 'Rohan Mehta', role: 'Software Engineer at Razorpay', initials: 'RM', color: 'avatar-blue' },
  { quote: 'We met our newest analyst on Spark. Thoughtful applicants, a simple process, and a much better way to find early career talent.', name: 'Meera Shah', role: 'People Partner at Groww', initials: 'MS', color: 'avatar-green' },
]

function Arrow({ diagonal = false }) {
  return <svg aria-hidden="true" viewBox="0 0 20 20" className="arrow-icon"><path d={diagonal ? 'M5 15 15 5M6 5h9v9' : 'M4 10h11m-4-4 4 4-4 4'} /></svg>
}

function Brand({ onClick }) {
  return <button className="brand" onClick={onClick} aria-label="Spark home"><img src={visteonLogo} alt="Visteon" /><span className="brand-name">spark</span></button>
}

function JobCard({ job, onApply }) {
  return <article className="job-card">
    <div className="job-card-top"><div className={`company-logo ${job.color}`}>{job.initials}</div><span className="posted">{job.posted}</span><button className="bookmark" aria-label={`Save ${job.role}`} onClick={(e) => e.currentTarget.classList.toggle('saved')}><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M5.5 3.5h9v13l-4.5-3-4.5 3z" /></svg></button></div>
    <div className="job-company">{job.company} <span className="verified">✓</span></div><h3>{job.role}</h3>
    <div className="job-tags"><span>{job.type}</span><span>{job.category}</span></div>
    <div className="job-meta"><span><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M16 8.2c0 4.2-6 8.3-6 8.3S4 12.4 4 8.2a6 6 0 1 1 12 0Z"/><circle cx="10" cy="8" r="2"/></svg>{job.location}</span><b>{job.salary}</b></div>
    <button className="apply-link" onClick={() => onApply(job)}>View opportunity <Arrow /></button>
  </article>
}

function clearAuthStorage() {
  for (const key of ['sparkAccessToken', 'sparkRefreshToken', 'sparkTokenType', 'sparkExpiresAt']) {
    localStorage.removeItem(key)
    sessionStorage.removeItem(key)
  }
}

async function fetchCurrentUser(accessToken, tokenType = 'Bearer') {
  const response = await fetch('https://spark-b4e0a6d6dxfjb6dx.westus3-01.azurewebsites.net/api/user', {
    headers: { Authorization: `${tokenType} ${accessToken}` },
  })
  const data = await response.json().catch(() => ({}))
  if (!response.ok) {
    const error = new Error(data.message || data.error || 'Could not load your account details.')
    error.status = response.status
    throw error
  }
  return data
}

function App() {
  const [page, setPage] = useState('home')
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All roles')
  const [toast, setToast] = useState('')
  const [selectedJob, setSelectedJob] = useState(null)
  const [mobileMenu, setMobileMenu] = useState(false)
  const [postedJobs, setPostedJobs] = useState([])
  const [loginLoading, setLoginLoading] = useState(false)
  const [loginError, setLoginError] = useState('')
  const [loginSuccess, setLoginSuccess] = useState(false)
  const [authUser, setAuthUser] = useState(null)
  const [authLoading, setAuthLoading] = useState(false)
  const [profileError, setProfileError] = useState('')
  const [credentials, setCredentials] = useState({ email: '', password: '' })
  const [form, setForm] = useState({ role: '', company: '', type: 'Full-time', location: '', category: 'Engineering', salary: '', description: '' })
  const allJobs = [...postedJobs, ...jobs]
  const filtered = useMemo(() => allJobs.filter((job) => (category === 'All roles' || job.category === category) && `${job.role} ${job.company} ${job.location} ${job.category}`.toLowerCase().includes(search.toLowerCase())), [allJobs, category, search])
  const notify = (message) => { setToast(message); window.setTimeout(() => setToast(''), 2800) }
  const navigate = (next) => { setPage(next); setMobileMenu(false); setSelectedJob(null); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  useEffect(() => {
    const restorePage = () => setPage(window.location.hash.replace('#', '') || 'home')
    window.addEventListener('popstate', restorePage)
    window.addEventListener('hashchange', restorePage)
    return () => {
      window.removeEventListener('popstate', restorePage)
      window.removeEventListener('hashchange', restorePage)
    }
  }, [])
  const go = (next) => { window.history.pushState({}, '', next === 'home' ? window.location.pathname : `#${next}`); navigate(next) }

  useEffect(() => {
    const accessToken = localStorage.getItem('sparkAccessToken')
    if (!accessToken) return undefined
    const tokenType = localStorage.getItem('sparkTokenType') || 'Bearer'
    let active = true
    setAuthLoading(true)
    fetchCurrentUser(accessToken, tokenType)
      .then((user) => {
        if (!active) return
        setAuthUser(user)
        setLoginSuccess(true)
        setProfileError('')
      })
      .catch((error) => {
        if (!active) return
        setProfileError(error.message || 'Could not load your account details.')
        if (error.status === 401) {
          clearAuthStorage()
          setLoginSuccess(false)
        }
      })
      .finally(() => { if (active) setAuthLoading(false) })
    return () => { active = false }
  }, [])

  const handlePost = (event) => {
    event.preventDefault()
    setPostedJobs((existing) => [{ ...form, id: Date.now(), company: form.company || 'Your company', initials: (form.company || 'S').slice(0, 1).toUpperCase(), color: 'teal', posted: 'Just now', salary: form.salary || 'Compensation varies' }, ...existing])
    setForm({ role: '', company: '', type: 'Full-time', location: '', category: 'Engineering', salary: '', description: '' })
    notify('Your opportunity is live on Spark.')
  }

  const handleLogin = async (event) => {
    event.preventDefault()
    setLoginLoading(true)
    setLoginError('')
    setLoginSuccess(false)

    try {
      const response = await fetch('https://spark-b4e0a6d6dxfjb6dx.westus3-01.azurewebsites.net/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: credentials.email.trim(), password: credentials.password }),
      })
      const data = await response.json().catch(() => ({}))

      if (!response.ok) {
        throw new Error(data.message || data.error || 'We could not sign you in. Check your details and try again.')
      }
      if (!data.accessToken) {
        throw new Error('The login service did not return an access token. Please try again.')
      }

      clearAuthStorage()
      localStorage.setItem('sparkAccessToken', data.accessToken)
      localStorage.setItem('sparkTokenType', data.tokenType || 'Bearer')
      localStorage.setItem('sparkExpiresAt', String(Date.now() + (data.expiresIn || 0) * 1000))
      if (data.refreshToken) localStorage.setItem('sparkRefreshToken', data.refreshToken)
      sessionStorage.removeItem('sparkAccessToken')
      sessionStorage.removeItem('sparkTokenType')
      sessionStorage.removeItem('sparkExpiresAt')
      sessionStorage.removeItem('sparkRefreshToken')
      setAuthLoading(true)
      setProfileError('')
      try {
        const user = await fetchCurrentUser(data.accessToken, data.tokenType || 'Bearer')
        setAuthUser(user)
      } catch (profileFetchError) {
        setAuthUser(null)
        setProfileError(profileFetchError.message || 'Signed in, but could not load your profile.')
        if (profileFetchError.status === 401) {
          clearAuthStorage()
          throw new Error('Your session was not accepted. Please sign in again.')
        }
      } finally {
        setAuthLoading(false)
      }
      setCredentials((current) => ({ ...current, password: '' }))
      setLoginSuccess(true)
      go('home')
    } catch (error) {
      setLoginError(error.message || 'Unable to connect to the login service. Please try again.')
    } finally {
      setLoginLoading(false)
    }
  }

  const handleLogout = () => {
    clearAuthStorage()
    setAuthUser(null)
    setAuthLoading(false)
    setLoginSuccess(false)
    setLoginError('')
    setProfileError('')
    setCredentials({ email: '', password: '' })
    go('home')
    notify('You have been logged out.')
  }

  return <div className="app-shell">
    <header className="site-header"><div className="nav-wrap"><Brand onClick={() => go('home')} />
      <nav className={mobileMenu ? 'main-nav open' : 'main-nav'} aria-label="Main navigation"><button className={page === 'home' ? 'nav-link active' : 'nav-link'} onClick={() => go('home')}>Home</button><button className={page === 'jobs' ? 'nav-link active' : 'nav-link'} onClick={() => go('jobs')}>View Projects</button><button className={page === 'manager' ? 'nav-link active' : 'nav-link'} onClick={() => go('manager')}>For managers</button>{authUser && <div className="mobile-user-summary"><b>{authUser.displayName}</b><span>{authUser.email}</span><em>{authUser.role}</em></div>}<button className="nav-link mobile-login-link" onClick={authUser ? handleLogout : () => go('login')}>{authUser ? 'Log out' : authLoading ? 'Loading account…' : 'Sign in'}</button></nav>
      <div className="nav-actions">{authUser && <div className="auth-user-summary"><b>{authUser.displayName}</b><span>{authUser.role}</span></div>}{authLoading && !authUser && <span className="auth-loading-label">Loading…</span>}<button className="signin" onClick={authUser ? handleLogout : () => go('login')}>{authUser ? 'Log out' : 'Sign in'}</button><button className="button button-teal nav-cta" onClick={() => go('manager')}>Post a role <Arrow /></button></div><button className="menu-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Toggle navigation"><span></span><span></span></button>
    </div></header>

    {page === 'login' && <main className="login-page"><div className="login-card"><div className="login-emblem">✳</div><span className="section-kicker">WELCOME BACK</span><h1>Good to see you.</h1><p className="login-intro">Sign in to continue to your Spark account.</p>{loginSuccess ? <div className="login-success login-profile" role="status"><span>✓</span><div><b>{authUser ? `Welcome, ${authUser.displayName}` : 'You’re signed in.'}</b>{authUser ? <><p>{authUser.email}</p><span className="profile-role">{authUser.role}</span></> : authLoading ? <p>Loading your account details…</p> : <p>Your session is ready.</p>}{profileError && <p className="profile-error">{profileError}</p>}</div><button className="button button-teal" onClick={() => go('home')}>Continue <Arrow /></button></div> : <form className="login-form" onSubmit={handleLogin}>
      <label>Email or username<input autoComplete="username" required value={credentials.email} onChange={(event) => setCredentials({ ...credentials, email: event.target.value })} placeholder="you@example.com" /></label>
      <label>Password<input autoComplete="current-password" type="password" required value={credentials.password} onChange={(event) => setCredentials({ ...credentials, password: event.target.value })} placeholder="Enter your password" /></label>
      {loginError && <p className="login-error" role="alert">{loginError}</p>}
      <button className="button button-teal login-submit" type="submit" disabled={loginLoading}>{loginLoading ? 'Signing in…' : 'Sign in'} {!loginLoading && <Arrow />}</button>
      <p className="login-help">New to Spark? <button type="button" onClick={() => go('jobs')}>Explore opportunities</button></p>
    </form>}</div><div className="login-aside"><span className="aside-spark">✳</span><p>Every great career starts somewhere.</p><span>Find your next step with Spark.</span></div></main>}

    {page === 'home' && <main>
      <section className="hero-section"><div className="hero-inner"><div className="hero-copy"><div className="eyebrow"><span className="eyebrow-dot"></span> A brighter start to your career</div><h1>Every big idea<br />starts with a <span>SPARK.</span></h1><p className="hero-subtitle">Spark connects fresh graduates with teams ready to give new talent a chance. Find a role that fits your ambition, your curiosity, and your next big idea.</p><div className="hero-buttons"><button className="button button-teal" onClick={() => go('jobs')}>Explore opportunities <Arrow /></button><button className="text-button" onClick={() => go('manager')}>I'm hiring <Arrow diagonal /></button></div><div className="hero-proof"><div className="avatar-stack"><span className="mini-avatar a1">A</span><span className="mini-avatar a2">R</span><span className="mini-avatar a3">M</span><span className="mini-avatar a4">+</span></div><div><strong>2,400+</strong><span>risers found their spark</span></div></div></div>
      <div className="hero-art" aria-label="Illustration of a new graduate exploring career opportunities"><div className="art-orbit orbit-one"></div><div className="art-orbit orbit-two"></div><div className="art-sun"></div><div className="art-spark">✳</div><div className="art-card card-one"><span className="tiny-logo logo-green">G</span><div><b>Product Designer</b><small>Bengaluru</small></div><span className="card-dot"></span></div><div className="art-card card-two"><span className="tiny-logo logo-blue">R</span><div><b>HMI Developer</b><small>Chennai</small></div></div><div className="person-illustration"><div className="person-shadow"></div><div className="person-body"></div><div className="person-neck"></div><div className="person-head"></div><div className="person-hair"></div><div className="person-arm"></div><div className="person-laptop"><span>✳</span></div></div><div className="art-caption"><span>✦</span> your next chapter, right this way</div></div></div></section>

      <section className="section jobs-section"><div className="section-heading"><div><span className="section-kicker">THE RIGHT FIRST STEP</span><h2>Opportunities worth<br className="desktop-break" /> getting excited about.</h2></div><button className="text-button view-all" onClick={() => go('jobs')}>View all roles <Arrow /></button></div><div className="job-grid home-job-grid">{jobs.slice(0, 3).map((job) => <JobCard key={job.id} job={job} onApply={setSelectedJob} />)}</div></section>

      <section className="how-section"><div className="how-intro"><span className="section-kicker">MADE FOR YOUR FIRST MOVE</span><h2>Good things happen<br />when you get started.</h2><p>Searching for your first opportunity can feel like a full-time job. Spark keeps it simple, human, and full of possibility.</p><button className="text-button" onClick={() => go('jobs')}>Find your starting point <Arrow /></button></div><div className="steps"><div className="step"><span className="step-num">01</span><div className="step-icon icon-search"><svg viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/></svg></div><div><h3>Find your fit</h3><p>Discover thoughtful roles from teams that are excited to meet early career talent.</p></div></div><div className="step"><span className="step-num">02</span><div className="step-icon icon-spark">✳</div><div><h3>Show what makes you, you</h3><p>Bring your skills, ideas, and curiosity. Your potential deserves the spotlight.</p></div></div><div className="step"><span className="step-num">03</span><div className="step-icon icon-arrow"><Arrow diagonal /></div><div><h3>Start your next chapter</h3><p>Meet people who will help you grow and do work that matters from day one.</p></div></div></div></section>

      <section className="testimonial-section"><div className="testimonial-heading"><span className="section-kicker">GOOD PEOPLE. GOOD STARTS.</span><h2>Don't just take our word for it.</h2><p>Check the testimonials.</p></div><div className="testimonial-grid">{testimonials.map((item) => <article className="testimonial-card" key={item.name}><div className="quote-mark">“</div><p className="quote">{item.quote}</p><div className="testimonial-person"><div className={`person-avatar ${item.color}`}>{item.initials}</div><div><b>{item.name}</b><span>{item.role}</span></div><span className="quote-stars">★★★★★</span></div></article>)}</div></section>
      <section className="bottom-cta"><div><span className="section-kicker">YOUR NEXT CHAPTER IS WAITING</span><h2>A little spark can go a long way.</h2><p>Take the first step. Your future self will thank you.</p></div><button className="button button-dark" onClick={() => go('jobs')}>Find an opportunity <Arrow /></button><span className="cta-flower">✳</span></section>
    </main>}

    {page === 'jobs' && <main className="page-main"><div className="page-hero jobs-hero"><div><span className="section-kicker">FIND YOUR NEXT STEP</span><h1>Make your first move.</h1><p>Explore opportunities from teams that are ready to help you grow.</p></div><div className="job-hero-mark">✳</div></div><div className="search-panel"><label className="search-box"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/></svg><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Role, title, or keyword" /></label><label className="filter-box"><span>Category</span><select value={category} onChange={(e) => setCategory(e.target.value)}>{['All roles', 'Engineering', 'Design', 'Product', 'Marketing', 'Operations'].map((option) => <option key={option}>{option}</option>)}</select></label><button className="button button-teal search-button" onClick={() => {}}>Search roles <Arrow /></button></div><div className="results-bar"><span><b>{filtered.length}</b> opportunities to explore</span><span>Showing newest first <span className="sort-icon">↕</span></span></div>{filtered.length ? <div className="job-grid listing-grid">{filtered.map((job) => <JobCard key={job.id} job={job} onApply={setSelectedJob} />)}</div> : <div className="empty-state"><span>✳</span><h3>No roles found just yet</h3><p>Try a different keyword or choose another category.</p><button className="text-button" onClick={() => { setSearch(''); setCategory('All roles') }}>Clear filters <Arrow /></button></div>}<div className="jobs-help"><span>Don't see the right fit?</span><button className="text-button" onClick={() => notify('New roles are added every week. Check back soon!')}>New opportunities land every week <Arrow /></button></div></main>}

    {page === 'manager' && <main className="page-main manager-main"><div className="manager-intro"><div><span className="section-kicker">FOR PEOPLE WHO BUILD TEAMS</span><h1>Meet your next<br /><span>great teammate.</span></h1><p>Great potential deserves a great first opportunity. Share your role with a community of curious, motivated risers ready to make an impact.</p><div className="manager-benefits"><span><i>✓</i> Reach early career talent</span><span><i>✓</i> Simple, thoughtful applications</span><span><i>✓</i> Find people who are ready to grow</span></div></div><div className="manager-graphic"><div className="manager-orbit"></div><div className="manager-bubble bubble-one">✳</div><div className="manager-bubble bubble-two">↗</div><div className="manager-note"><span className="note-label">A good match</span><div className="note-person"><span className="note-avatar">AK</span><div><b>Arjun Kumar</b><small>Product Design · 2026</small></div><span className="match-score">98%</span></div><div className="match-bars"><i></i><i></i><i></i></div><span className="note-bottom">Curiosity meets opportunity</span></div></div></div><div className="post-form-wrap"><div className="form-heading"><div><span className="section-kicker">SHARE AN OPPORTUNITY</span><h2>Post a role on Spark</h2><p>It takes just a few details to get started.</p></div><span className="form-step">01 <i>/</i> 01</span></div><form className="post-form" onSubmit={handlePost}><div className="form-grid"><label><span className="field-label">Job title <i>*</i></span><input required value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} placeholder="e.g. Junior Product Designer" /></label><label><span className="field-label">Company <i>*</i></span><input required value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} placeholder="Your company name" /></label><label><span className="field-label">Employment type <i>*</i></span><select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}><option>Full-time</option><option>Internship</option><option>Contract</option><option>Part-time</option></select></label><label><span className="field-label">Category <i>*</i></span><select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{['Engineering', 'Design', 'Product', 'Marketing', 'Operations'].map((item) => <option key={item}>{item}</option>)}</select></label><label><span className="field-label">Location <i>*</i></span><input required value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="e.g. Bengaluru · Hybrid" /></label><label><span className="field-label">Compensation <small>Optional</small></span><input value={form.salary} onChange={(e) => setForm({ ...form, salary: e.target.value })} placeholder="e.g. ₹8–10 LPA" /></label><label className="full-field"><span className="field-label">A little about the role <small>Optional</small></span><textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="What will this person work on? What makes your team a great place to start?" rows="4" /></label></div><div className="form-footer"><p>By posting, you agree to welcome applicants at the start of their career.</p><button className="button button-teal" type="submit">Publish opportunity <Arrow /></button></div></form></div><div className="manager-footnote"><span>✳</span><p>Looking for your first role? <button onClick={() => go('jobs')}>Explore opportunities</button></p></div></main>}

    <footer className="site-footer"><div className="footer-main"><div className="footer-brand"><Brand onClick={() => go('home')} /><p>A brighter start to your career.<br />Made for risers, built for what's next.</p></div><div className="footer-links"><div><b>Explore</b><button onClick={() => go('jobs')}>Find a job</button><button onClick={() => go('manager')}>Post a role</button></div><div><b>About Spark</b><button onClick={() => notify('Spark is here to make the first step a little easier.')}>Our story</button><button onClick={() => notify('Say hello at hello@spark.careers')}>Get in touch</button></div></div><div className="footer-note"><span>Made for the beginning.</span><b>✳</b></div></div><div className="footer-bottom"><span>© 2026 Visteon Corporation</span><span>Good things start here <b>✳</b></span><span>Privacy&nbsp;&nbsp;&nbsp; Terms</span></div></footer>

    {selectedJob && <div className="modal-backdrop" onClick={() => setSelectedJob(null)}><section className="job-modal" onClick={(e) => e.stopPropagation()}><button className="modal-close" onClick={() => setSelectedJob(null)} aria-label="Close">×</button><div className={`company-logo ${selectedJob.color}`}>{selectedJob.initials}</div><span className="section-kicker">{selectedJob.company} · {selectedJob.location}</span><h2>{selectedJob.role}</h2><div className="job-tags"><span>{selectedJob.type}</span><span>{selectedJob.category}</span></div><p>Bring your curiosity and point of view to a team that wants to help you grow. This opportunity is designed for someone at the start of their career who is ready to learn, contribute, and make an impact.</p><div className="modal-salary">Compensation <b>{selectedJob.salary}</b></div><button className="button button-teal modal-apply" onClick={() => { setSelectedJob(null); notify('Application flow is coming soon. Your interest has been noted!') }}>Apply for this role <Arrow /></button></section></div>}
    {toast && <div className="toast" role="status"><span>✳</span>{toast}</div>}
  </div>
}

export default App
